<html>
<head></head>

<body>

<?php 

	echo 'Title:' . $Files->title . '<br/>';
	echo 'Author:' . $Files->author . '<br/>';
	echo 'Description:' . $Files->description . '<br/>';

?>

</body>
</html>