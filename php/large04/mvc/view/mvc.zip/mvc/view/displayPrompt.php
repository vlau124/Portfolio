<html>
<head>
  <!-- doesn't work on the controller page-->
  <link rel="stylesheet" href="style.css">
</head>

<body>

<?php 
  //create a new button for person to logout

echo <<<END
<h1>Large Project 4 - MVC</h1>
<p>
This is a web based building security log book with the following features:<br><br>
- User enters their name and who they are visiting into web form & utilizes Ajax.<br>
- Store user information along with sign-in time (automatically generated) and sign-out time.<br>
- Displays number of people in the building and the average visiting length.<br>
- Use a cookie to store information about the last person to sign in on this machine, so when they click leave building it will default to their name.<br>
- Uses only one URL for all form submissions signing in and out.<br>
- Uses only one index.php file to process all functions.<br>
</p>


END;



?>

<h3><b>
I am not sure how I would display code for this yet., but here is a download link. <a href="mvc.zip">Download Here mvc.zip</a>
</b></h3>

</body>
</html>

<!--
-->